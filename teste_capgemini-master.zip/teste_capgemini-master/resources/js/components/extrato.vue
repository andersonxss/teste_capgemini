<template>
  <div class="card">
                    <div class="card-header">Home</div>

                    <div class="card-body">
                        I'm an example component.
                    </div>
                </div>
</template>


<script>
    export default {
        mounted() {
            console.log('Component mounted.')
        }
    }
</script>
